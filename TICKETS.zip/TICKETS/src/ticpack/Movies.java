package ticpack;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;

public class Movies  extends JDialog implements ActionListener  {
	private JTextField txtAvengerEndgame;
	private JButton btnNewButton;

	public Movies() {
		setTitle("MOVIE");
		getContentPane().setLayout(null);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(Movies.class.getResource("/ticpack/images/download (2).jpg")));
		label_1.setBounds(196, 13, 157, 212);
		getContentPane().add(label_1);
		
		txtAvengerEndgame = new JTextField();
		txtAvengerEndgame.setOpaque(false);
		txtAvengerEndgame.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtAvengerEndgame.setText("AVENGER ENDGAME");
		txtAvengerEndgame.setBounds(174, 263, 195, 22);
		getContentPane().add(txtAvengerEndgame);
		txtAvengerEndgame.setColumns(10);
		
		btnNewButton = new JButton("BOOK SEATS");
		btnNewButton.addActionListener(this);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(211, 326, 131, 25);
		getContentPane().add(btnNewButton);
		setSize(597,444);
		setVisible(true);
	}

	public static void main(String[] args) {
		new Movies();
		

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		Object ob=arg0.getSource();
		if(ob==btnNewButton){
			new Seats();
		}
	}
}
