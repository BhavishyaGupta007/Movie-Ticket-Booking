package ticpack;

import java.sql.*;
public class DBConnection {
	static Connection con;
	static Connection connect() {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver ok");
			String url="jdbc:mysql://localhost:3306/tickets";
			String user="root";
			String pass="1234";
			con=DriverManager.getConnection(url,user,pass);
			System.out.println("Connected");
		}
		catch(ClassNotFoundException se) {
			se.printStackTrace();
		}
		catch(SQLException se) {
			se.printStackTrace();
		}
		return con;
	}
	public static void main(String ar[]) {
		connect();
	}
}