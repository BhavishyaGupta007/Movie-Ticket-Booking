package ticpack;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.UIManager;
import javax.swing.SwingConstants;

public class Welcome extends JDialog implements ActionListener  {
	private JTextField txtMovieBooker;
	private JButton btnExploreMovies;

	public Welcome() {
		setTitle("WELCOME");
		getContentPane().setForeground(Color.BLACK);
		getContentPane().setEnabled(false);
		getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 32));
		getContentPane().setLayout(null);
		
		txtMovieBooker = new JTextField();
		txtMovieBooker.setVisible(true);
		txtMovieBooker.setOpaque(false);
		txtMovieBooker.setBackground(SystemColor.text);
		txtMovieBooker.setForeground(Color.BLACK);
		txtMovieBooker.setFont(new Font("MV Boli", Font.PLAIN, 36));
		txtMovieBooker.setText("MOOVIE BOOKER");
		txtMovieBooker.setBounds(221, 127, 316, 50);
		getContentPane().add(txtMovieBooker);
		txtMovieBooker.setColumns(10);
		
		btnExploreMovies = new JButton("Book Tickets now");
		btnExploreMovies.addActionListener(this);
		btnExploreMovies.setForeground(Color.BLACK);
		btnExploreMovies.setBackground(UIManager.getColor("Button.focus"));
		btnExploreMovies.setFont(new Font("Tahoma", Font.PLAIN, 23));
		btnExploreMovies.setBounds(264, 283, 230, 25);
		getContentPane().add(btnExploreMovies);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Welcome.class.getResource("/ticpack/images/Screenshot (24).png")));
		label.setBounds(0, 0, 724, 440);
		getContentPane().add(label);
		setSize(742,500);
		setVisible(true);
	}

	public static void main(String[] args) {
		new Welcome();
	
	}

	@Override 
	public void actionPerformed(ActionEvent arg0) {
		 if(arg0.getSource()==btnExploreMovies) 
		 {
			 new Movies();
		 }
		
	}
}
