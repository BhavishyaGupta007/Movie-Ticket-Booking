package ticpack;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JTextField;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;

import java.awt.Color;

import javax.swing.JCheckBox;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JLabel;


public class Seats  extends JDialog implements ActionListener   {
	private JTextField txtGold;
	private JTextField txtClassic;
	LineBorder lb=new LineBorder(Color.red,4);
	private JButton btnA;
	private JButton btnB;
	private JButton btnC;
	private JButton btnD;
	private JButton btnE;
	private JButton btnF;
	private JButton btnG;
	private JButton btnH;
	private JButton btnI;
	private JButton btnJ;
	private JButton btnK;
	private JButton btnL;
	private JButton btnM;
	private JButton btnN;
	private JButton btnO;
	private JButton btnP;
	private JButton btnQ;
	private JButton btnR;
	private JButton btnS;
	private JButton btnT;
	private JButton btnU;
	private JButton btnV;
	private JButton btnW;
	private JButton btnX;
	java.sql.Date date;
	private JLabel tdate;
	int sno;
	public Seats() {
		getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 14));
		setTitle("Seats");
		getContentPane().setLayout(null);

		txtGold = new JTextField();
		txtGold.setOpaque(false);
		txtGold.setFont(new Font("Tahoma", Font.BOLD, 15));
		txtGold.setText("GOLD");
		txtGold.setBounds(190, 13, 53, 22);
		getContentPane().add(txtGold);
		txtGold.setColumns(10);

		btnA = new JButton("1");
		btnA.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnA.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnA.setBounds(12, 60, 39, 43);
		getContentPane().add(btnA);


		btnB = new JButton("2");
		btnB.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnB.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnB.setBounds(63, 60, 39, 43);
		getContentPane().add(btnB);

		btnC = new JButton("3");
		btnC.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnC.setBounds(114, 60, 39, 43);
		getContentPane().add(btnC);

		btnD = new JButton("4");
		btnD.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnD.setBounds(163, 60, 39, 43);
		getContentPane().add(btnD);

		btnE = new JButton("5");
		btnE.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnE.setBounds(228, 60, 39, 43);
		getContentPane().add(btnE);

		btnF = new JButton("6");
		btnF.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnF.setBounds(279, 60, 39, 43);
		getContentPane().add(btnF);

		btnG = new JButton("7");
		btnG.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnG.setBounds(330, 60, 39, 43);
		getContentPane().add(btnG);

		btnH = new JButton("8");
		btnH.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnH.setBounds(381, 60, 39, 43);
		getContentPane().add(btnH);

		txtClassic = new JTextField();
		txtClassic.setOpaque(false);
		txtClassic.setFont(new Font("Tahoma", Font.BOLD, 15));
		txtClassic.setText("CLASSIC");
		txtClassic.setBounds(181, 134, 76, 22);
		getContentPane().add(txtClassic);
		txtClassic.setColumns(10);

		btnI = new JButton("9");
		btnI.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnI.setBounds(12, 191, 39, 43);
		getContentPane().add(btnI);

		btnJ = new JButton("10");
		btnJ.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnJ.setBounds(63, 191, 39, 43);
		getContentPane().add(btnJ);

		btnK = new JButton("11");
		btnK.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnK.setBounds(114, 191, 39, 43);
		getContentPane().add(btnK);

		btnL = new JButton("12");
		btnL.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnL.setBounds(163, 191, 39, 43);
		getContentPane().add(btnL);

		btnM = new JButton("13");
		btnM.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnM.setBounds(228, 191, 39, 43);
		getContentPane().add(btnM);

		btnN = new JButton("14");
		btnN.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnN.setBounds(279, 191, 39, 43);
		getContentPane().add(btnN);

		btnO = new JButton("15");
		btnO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnO.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnO.setBounds(330, 191, 39, 43);
		getContentPane().add(btnO);

		btnP = new JButton("16");
		btnP.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnP.setBounds(381, 191, 39, 43);
		getContentPane().add(btnP);

		btnQ = new JButton("17");
		btnQ.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnQ.setBounds(12, 273, 39, 43);
		getContentPane().add(btnQ);

		btnR = new JButton("18");
		btnR.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnR.setBounds(63, 273, 39, 43);
		getContentPane().add(btnR);

		btnS = new JButton("19");
		btnS.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnS.setBounds(114, 273, 39, 43);
		getContentPane().add(btnS);

		btnT = new JButton("20");
		btnT.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnT.setBounds(163, 273, 39, 43);
		getContentPane().add(btnT);

		btnU = new JButton("21");
		btnU.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnU.setBounds(228, 273, 39, 43);
		getContentPane().add(btnU);

		btnV = new JButton("22");
		btnV.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnV.setBounds(279, 273, 39, 43);
		getContentPane().add(btnV);

		btnW = new JButton("23");
		btnW.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnW.setBounds(330, 273, 39, 43);
		getContentPane().add(btnW);

		btnX = new JButton("24");
		btnX.setIcon(new ImageIcon(Seats.class.getResource("/ticpack/images/icons8-theatre-seat-40.png")));
		btnX.setBounds(381, 273, 39, 43);
		getContentPane().add(btnX);

		date=new java.sql.Date(new java.util.Date().getTime());

		tdate = new JLabel(date.toString());
		tdate.setFont(new Font("Tahoma", Font.PLAIN, 16));
		tdate.setBounds(12, 8, 123, 32);
		getContentPane().add(tdate);

		//		txtA = new JTextField();
		//		txtA.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtA.setOpaque(false);
		//		txtA.setVerifyInputWhenFocusTarget(false);
		//		txtA.setText("A");
		//		txtA.setBounds(23, 37, 15, 22);
		//		getContentPane().add(txtA);
		//		txtA.setColumns(10);
		//		
		//		txtB = new JTextField();
		//		txtB.setOpaque(false);
		//		txtB.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtB.setText("B");
		//		txtB.setBounds(72, 37, 15, 22);
		//		getContentPane().add(txtB);
		//		txtB.setColumns(10);
		//		
		//		txtC = new JTextField();
		//		txtC.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtC.setOpaque(false);
		//		txtC.setText("C");
		//		txtC.setBounds(124, 38, 15, 22);
		//		getContentPane().add(txtC);
		//		txtC.setColumns(10);
		//		
		//		txtD = new JTextField();
		//		txtD.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtD.setOpaque(false);
		//		txtD.setText("D");
		//		txtD.setBounds(168, 38, 15, 22);
		//		getContentPane().add(txtD);
		//		txtD.setColumns(10);
		//		
		//		txtE = new JTextField();
		//		txtE.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtE.setOpaque(false);
		//		txtE.setText("E");
		//		txtE.setBounds(242, 38, 15, 22);
		//		getContentPane().add(txtE);
		//		txtE.setColumns(10);
		//		
		//		txtF = new JTextField();
		//		txtF.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtF.setOpaque(false);
		//		txtF.setRequestFocusEnabled(false);
		//		txtF.setText("F");
		//		txtF.setBounds(289, 38, 15, 22);
		//		getContentPane().add(txtF);
		//		txtF.setColumns(10);
		//		
		//		txtG = new JTextField();
		//		txtG.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtG.setOpaque(false);
		//		txtG.setText("G");
		//		txtG.setBounds(338, 38, 15, 22);
		//		getContentPane().add(txtG);
		//		txtG.setColumns(10);
		//		
		//		txtH = new JTextField();
		//		txtH.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtH.setOpaque(false);
		//		txtH.setText("H");
		//		txtH.setBounds(392, 38, 15, 22);
		//		getContentPane().add(txtH);
		//		txtH.setColumns(10);
		//		
		//		txtI = new JTextField();
		//		txtI.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtI.setOpaque(false);
		//		txtI.setText("I");
		//		txtI.setBounds(23, 168, 15, 22);
		//		getContentPane().add(txtI);
		//		txtI.setColumns(10);
		//		
		//		txtJ = new JTextField();
		//		txtJ.setOpaque(false);
		//		txtJ.setText("J");
		//		txtJ.setBounds(72, 169, 15, 22);
		//		getContentPane().add(txtJ);
		//		txtJ.setColumns(10);
		//		
		//		txtK = new JTextField();
		//		txtK.setOpaque(false);
		//		txtK.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtK.setText("K");
		//		txtK.setBounds(124, 168, 15, 22);
		//		getContentPane().add(txtK);
		//		txtK.setColumns(10);
		//		
		//		txtL = new JTextField();
		//		txtL.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtL.setOpaque(false);
		//		txtL.setText("L");
		//		txtL.setBounds(168, 168, 15, 22);
		//		getContentPane().add(txtL);
		//		txtL.setColumns(10);
		//		
		//		txtM = new JTextField();
		//		txtM.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtM.setOpaque(false);
		//		txtM.setText("M");
		//		txtM.setBounds(242, 169, 15, 22);
		//		getContentPane().add(txtM);
		//		txtM.setColumns(10);
		//		
		//		txtN = new JTextField();
		//		txtN.setOpaque(false);
		//		txtN.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtN.setText("N");
		//		txtN.setBounds(289, 168, 15, 22);
		//		getContentPane().add(txtN);
		//		txtN.setColumns(10);
		//		
		//		txtP = new JTextField();
		//		txtP.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtP.setOpaque(false);
		//		txtP.setText("O");
		//		txtP.setBounds(337, 169, 16, 22);
		//		getContentPane().add(txtP);
		//		txtP.setColumns(10);
		//		
		//		txtP_1 = new JTextField();
		//		txtP_1.setOpaque(false);
		//		txtP_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtP_1.setText("P");
		//		txtP_1.setBounds(392, 168, 15, 22);
		//		getContentPane().add(txtP_1);
		//		txtP_1.setColumns(10);
		//		
		//		txtQ = new JTextField();
		//		txtQ.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtQ.setOpaque(false);
		//		txtQ.setText("Q");
		//		txtQ.setBounds(22, 247, 16, 22);
		//		getContentPane().add(txtQ);
		//		txtQ.setColumns(10);
		//		
		//		txtR = new JTextField();
		//		txtR.setOpaque(false);
		//		txtR.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtR.setText("R");
		//		txtR.setBounds(73, 247, 15, 22);
		//		getContentPane().add(txtR);
		//		txtR.setColumns(10);
		//		
		//		txtS = new JTextField();
		//		txtS.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtS.setOpaque(false);
		//		txtS.setText("S");
		//		txtS.setBounds(124, 247, 15, 22);
		//		getContentPane().add(txtS);
		//		txtS.setColumns(10);
		//		
		//		txtT = new JTextField();
		//		txtT.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtT.setOpaque(false);
		//		txtT.setText("T");
		//		txtT.setBounds(173, 247, 15, 22);
		//		getContentPane().add(txtT);
		//		txtT.setColumns(10);
		//		
		//		txtU = new JTextField();
		//		txtU.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtU.setOpaque(false);
		//		txtU.setText("U");
		//		txtU.setBounds(242, 247, 15, 22);
		//		getContentPane().add(txtU);
		//		txtU.setColumns(10);
		//		
		//		txtV = new JTextField();
		//		txtV.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtV.setOpaque(false);
		//		txtV.setText("V");
		//		txtV.setBounds(289, 247, 15, 22);
		//		getContentPane().add(txtV);
		//		txtV.setColumns(10);
		//		
		//		txtW = new JTextField();
		//		txtW.setOpaque(false);
		//		txtW.setFont(new Font("Tahoma", Font.PLAIN, 14));
		//		txtW.setText("W");
		//		txtW.setBounds(340, 247, 23, 22);
		//		getContentPane().add(txtW);
		//		txtW.setColumns(10);
		//		
		//		txtX = new JTextField();
		//		txtX.setOpaque(false);
		//		txtX.setText("X");
		//		txtX.setBounds(391, 247, 15, 22);
		//		getContentPane().add(txtX);
		//		txtX.setColumns(10);
		btnA.addActionListener(this);
		btnB.addActionListener(this);
		btnC.addActionListener(this);
		btnD.addActionListener(this);
		btnE.addActionListener(this);
		btnF.addActionListener(this);
		btnG.addActionListener(this);
		btnH.addActionListener(this);
		btnI.addActionListener(this);
		btnJ.addActionListener(this);
		btnK.addActionListener(this);
		btnL.addActionListener(this);
		btnM.addActionListener(this);
		btnN.addActionListener(this);
		btnO.addActionListener(this);
		btnP.addActionListener(this);
		btnQ.addActionListener(this);
		btnR.addActionListener(this);
		btnS.addActionListener(this);
		btnT.addActionListener(this);
		btnU.addActionListener(this);
		btnV.addActionListener(this);
		btnW.addActionListener(this);
		btnX.addActionListener(this);
		setSize(456, 419);
		setVisible(true);
	}

	public static void main(String[] args) {
		new Seats();

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		Object ob=arg0.getSource();
		sno=Integer.parseInt(arg0.getActionCommand());
		boolean b=checkInTable();
		if(b)
			new Register(sno,date);
	}
	boolean checkInTable() {
		String st="select seatno from seatdetails where seatno=? and bdate=?";
		Connection c=DBConnection.connect();
		try {
			PreparedStatement ps=c.prepareStatement(st);
			ps.setInt(1, sno);
			ps.setDate(2, date);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				JOptionPane.showMessageDialog(this, "Seat Already Booked");
				return false;
			}
			else  {
				return true;
			}

		}
		catch(SQLException se) {
			se.printStackTrace();
		}
		return false;
	}
}
