package ticpack;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.SwingConstants;

public class Register extends JFrame implements ActionListener  {
	private JTextField tname;
	private JTextField temail;
	private JTextField tphone;
	private JTextField tseatno;
	private JButton register;
	int sno;
	java.sql.Date date;
	public Register(int sno, java.sql.Date date) {
		this.date=date;
		this.sno=sno;
		setSize(450,300);
		setTitle("Register");
		getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name :");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblName.setBounds(53, 72, 73, 16);
		getContentPane().add(lblName);
		
		tname = new JTextField();
		tname.setBounds(149, 71, 237, 22);
		getContentPane().add(tname);
		tname.setColumns(10);
		
		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblEmail.setBounds(53, 112, 73, 16);
		getContentPane().add(lblEmail);
		
		temail = new JTextField();
		temail.setBounds(149, 111, 237, 22);
		getContentPane().add(temail);
		temail.setColumns(10);
		
		JLabel lblPhNumber = new JLabel("Ph. no. :");
		lblPhNumber.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblPhNumber.setBounds(36, 165, 90, 16);
		getContentPane().add(lblPhNumber);
		
		tphone = new JTextField();
		tphone.setBounds(149, 164, 237, 22);
		getContentPane().add(tphone);
		tphone.setColumns(10);
		register=new JButton("Register");
		register.setFont(new Font("Tahoma", Font.PLAIN, 15));
		register.setBounds(159, 204, 111, 25);
		getContentPane().add(register);
		
		JLabel lblSeatNo = new JLabel("Seat No");
		lblSeatNo.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSeatNo.setBounds(53, 29, 73, 16);
		getContentPane().add(lblSeatNo);
		
		tseatno = new JTextField(""+sno);
		tseatno.setFont(new Font("Tahoma", Font.PLAIN, 16));
		tseatno.setHorizontalAlignment(SwingConstants.CENTER);
		tseatno.setColumns(10);
		tseatno.setBounds(149, 23, 237, 22);
		getContentPane().add(tseatno);
		register.addActionListener(this);
		setSize(450,300);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		if(arg0.getSource()==register)
		{
			int seat=Integer.parseInt(tseatno.getText());
			String name=tname.getText();
			String email=temail.getText();
			String phone=tphone.getText();
			
			try {
				Long.parseLong(phone);
				if(phone.length()!=10)
					throw new NumberFormatException();
			}
			catch(NumberFormatException|NullPointerException nfe) {
				JOptionPane.showMessageDialog(null, "Error in Mobile Number");
				tphone.requestFocusInWindow();
				return;
			}
			
			String st="insert into seatDetails(seatno, name, email, mobile,Bdate)values(?,?,?,?,?)";
			Connection c=DBConnection.connect();
			try {
				PreparedStatement ps=c.prepareStatement(st);
				ps.setInt(1, seat);
				ps.setString(2, name);
				ps.setString(3, email);
				ps.setString(4, phone);
				ps.setDate(5,date);
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registered");
				dispose();
			}
			catch(SQLException se) {
				se.printStackTrace();
			}
			
		}
	}
}
